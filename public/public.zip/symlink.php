<?php

symlink(__DIR__ . '/../storage/app/public', './storage');